// For Banker
// Pusrpose is to add an account

const express = require('express');
const mongoose = require("mongoose");
const { MongoClient } = require('mongodb');
const app = express();
const port = 3000;
const transaction = require('./../models/transaction');


// Middleware to parse JSON bodies
app.use(express.json());

const client = new MongoClient(url, {
     useNewUrlParser: true, 
     useUnifiedTopology: true }
);

// Define the API endpoint to add an user
app.post('/credit', async (req, res) => {
    try {
        const transactDetails = req.body;

        console.log("Request body is: " + JSON.stringify(req.body, null, 2));
        console.log("userDetails is: " + JSON.stringify(transactDetails, null, 2));

        const db = client.db(dbName);
        const accountCollection = db.collection('Account');

        console.log("Paid To: " + transactDetails.PaidTo + " Reciever: " + transactDetails.Receiver + 
                    " Transaction Type: " + transactDetails.TransactionType + " Amount: " + transactDetails.Amount);

        const receiver = await accountCollection.findOne({ AccountNumber: req.body.PaidTo });
        console.log("receiver: " + JSON.stringify(receiver, null, 2));
        if (!receiver) {
            console.log("Returning 400: Receiver account does not exist");
            return res.status(400).json({ error: "Receiver account doesn't exist" });
        }

        const sender = await accountCollection.findOne({ AccountNumber: req.body.Receiver });
        console.log("sender: " + JSON.stringify(sender, null, 2));
        if (!sender) {
            console.log("Returning 400: Sender account does not exist");
            return res.status(400).json({ error: "Sender account doesn't exist" });
        }

        const Amount = parseFloat(req.body.Amount);
        const transactionType = req.body.TransactionType;

        if (transactionType === 'Credit') {
            if (sender.Balance < Amount) {
                return res.status(400).json({ message: 'Insufficient funds' });
            }

            const updateSender = await accountCollection.updateOne(
                { AccountNumber: req.body.ReceivedFrom },
                { $inc: { Balance: -Amount } }
            );

            const updateReceiver = await accountCollection.updateOne(
                { AccountNumber: req.body.PaidTo },
                { $inc: { Balance: Amount } }
            );

        } else if (TransactionType === 'Debit') {
            if (sender.Balance >= Amount) {
                const updateSender = await accountCollection.updateOne(
                    { AccountNumber: req.body.ReceivedFrom },
                    { $inc: { Balance: -Amount } }
                );
            } else {
                return res.status(400).json({ message: 'Insufficient funds' });
            }
        } else {
            return res.status(400).json({ message: 'Invalid transaction type' });
        }

        res.status(200).json({ message: 'Transaction successful' });

    } catch (err) {
        console.error("Error during transaction:", err);
        res.status(500).json({ message: 'Internal server error' });
    }
});




     /*
        find paidto user
        find recieeved from user
        if transaction type is credit {
            if (recieved from user balance> amount){
                balance = balance - amount;
                balance2 = balance + amount
            }
            else{
                return error insufficient funds
            }
        }
        elseif(transactiontype == debit){
            if (recieved from user balance> amount){
                balance = balance - amount;
            }
            else{
                return error insufficient funds
            }
        }
*/