class Account{
        AccountNumbers;
        AccountType;
        Balance;
        LastTransaction;
        AccountCreated;
        AccountHolder_Type;
        Holder
    }
module.exports = Account;