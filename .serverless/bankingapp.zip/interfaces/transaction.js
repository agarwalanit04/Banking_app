class Transaction{
        TransactionDate;
        TransactionType;
        PaidTo;
        ReceivedFrom;
        Amount;
}
module.exports = Transaction;