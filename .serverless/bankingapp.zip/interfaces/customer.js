class Customer {   
    AccountNumber;
    Name;
    Email;
    Phone;
    Address;
}
module.exports = Customer;
