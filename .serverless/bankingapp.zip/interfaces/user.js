class User{
        Name;
        Role;
        AccountNumber;
        Email;
        Phone ;
        Address ;
        DOB ;
        Password ;
}
module.exports = User;